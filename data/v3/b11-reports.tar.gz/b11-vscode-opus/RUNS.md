| Folder | Setup | Source run | When, with what |
| --- | --- | --- | --- |
| r1 | Claude Code alone | b11-q300-opus/r1 | 2026-11-01..05, Claude Code 2.1.x |
| r1 | + Graphify | b11-q300-opus/r1 | 2026-11-01..05, Claude Code 2.1.x |
| r3 | Claude Code alone | main-vscode-opus-v120-alone | 2026-11-23, Claude Code 2.1.330 |
| r3 | + Graphify | main-vscode-opus-v120-gfy | 2026-11-23, Claude Code 2.1.330 |
| r4 | + PipesHub | main-vscode-opus-v120-r1 | 2026-11-22, PipesHub v1.2.0, Claude Code 2.1.330 |
| r5 | + PipesHub | main-vscode-opus-v120-r2 | 2026-11-22, PipesHub v1.2.0, Claude Code 2.1.330 |
