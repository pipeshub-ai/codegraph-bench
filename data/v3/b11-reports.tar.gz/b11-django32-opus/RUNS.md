| Folder | Setup | Source run | When, with what |
| --- | --- | --- | --- |
| r1 | Claude Code alone | b12-q300-opus/r1 | 2026-11-01..05, Claude Code 2.1.x |
| r1 | + Graphify | b12-q300-opus/r1 | 2026-11-01..05, Claude Code 2.1.x |
| r2 | Claude Code alone | b12-q300-opus/r2 | 2026-11-01..05, Claude Code 2.1.x |
| r4 | Claude Code alone | main-django-opus-v120-alone | 2026-11-23, Claude Code 2.1.330 |
| r4 | + Graphify | main-django-opus-v120-gfy | 2026-11-23, Claude Code 2.1.330 |
| r5 | + PipesHub | main-django-opus-v120-r1 | 2026-11-22, PipesHub v1.2.0, Claude Code 2.1.330 |
| r6 | + PipesHub | main-django-opus-v120-r2 | 2026-11-22, PipesHub v1.2.0, Claude Code 2.1.330 |
