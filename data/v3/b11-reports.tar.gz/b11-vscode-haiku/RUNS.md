| Folder | Setup | Source run | When, with what |
| --- | --- | --- | --- |
| r1 | Claude Code alone | b11-q300-haiku/r1 | 2026-11-01..05, Claude Code 2.1.x |
| r1 | + Graphify | b11-q300-haiku/r1 | 2026-11-01..05, Claude Code 2.1.x |
| r2 | Claude Code alone | b11-q300-haiku/r2 | 2026-11-01..05, Claude Code 2.1.x |
| r2 | + Graphify | b11-q300-haiku/r2 | 2026-11-01..05, Claude Code 2.1.x |
| r4 | Claude Code alone | main-vscode-haiku-v120-alone | 2026-11-23, Claude Code 2.1.330 |
| r4 | + Graphify | main-vscode-haiku-v120-gfy | 2026-11-23, Claude Code 2.1.330 |
| r5 | + PipesHub | main-vscode-haiku-v120-r1 | 2026-11-22, PipesHub v1.2.0, Claude Code 2.1.330 |
| r6 | + PipesHub | main-vscode-haiku-v120-r2 | 2026-11-22, PipesHub v1.2.0, Claude Code 2.1.330 |
